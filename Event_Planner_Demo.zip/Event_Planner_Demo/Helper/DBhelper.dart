import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DBHelper
{
  //Create Instance Variable & Assign Values (DataBase Name & Table Name)
  static Database? _database;
  static const String dbName = 'mydb';
  static const String userTable = 'user';

  DBHelper._privateConstructor();

  //Create DataBAse Helper Class Object
  static final DBHelper instance = DBHelper._privateConstructor();

  //Create DataBase
  Future<Database> _initDataBase() async{
    String myDbPath =  join(await getDatabasesPath(),dbName);

    //Call OpenDataBase Method & Return Object & Create Table
    return await openDatabase(myDbPath, version: 1, onCreate: _onCreate);
  }

  Future<Database> get database async{
    if(_database != null)
    {
      return _database!;
    }
    else
    {
      _database = await _initDataBase();
      return _database!;
    }
  }

  Future<void> _onCreate(Database db,int version) async{

  }
}