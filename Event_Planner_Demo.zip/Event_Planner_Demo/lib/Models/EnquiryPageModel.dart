import 'package:event_planner_demo/Models/EnquiryPageModel.dart';

class EnquiryRequest {
  String? Name;
  String? Contact;
  String? alt_Contact;
  String? Event_date;
  String? Email;
  String? event_id;
  String? enq_message;

  EnquiryRequest(String? Name, String? enq_Contact, String? alt_Contact,
      String? Event_date, String Email, String enq_message) {

    this.Name = Name ?? 'John Doe'; //??: This is the null-coalescing operator in Dart. It checks if the value on its left side is null.
    this.Contact = Contact ?? '1234567890';
    this.alt_Contact = alt_Contact ?? '9876543210"';
    this.Event_date = Event_date ?? '2024-06-15T12:00:00Z';
    this.Email = Email ?? 'johndoe@example.com';
    this.event_id = event_id ?? '4';
    this.enq_message = enq_message ?? 'Interested in booking an event';
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> mapping = {
      "enq_name": Name,
      "enq_contact": Contact,
      "alt_contact": alt_Contact,
      "event_date": Event_date,
      "email": Email,
      "enq_event_id": event_id,
      "enq_msg": enq_message,
    };
    return mapping;
  }
}

class EnquiryResponse {
  // Initialization of JSON keys
  bool? status;
  dynamic? data;
  String? message;

  // EnquiryResponse is an object
  EnquiryResponse({ this.status,this.data, this.message});

  factory EnquiryResponse.fromJSON(Map<String,dynamic> map) {
    return EnquiryResponse(
       status: map["status"] != null ? map["status"] : true,
       data: map["data"]  != null ? map["data"] : " ",
       message: map["message"] != null ? map["message"] : "",
    );
  }
}
