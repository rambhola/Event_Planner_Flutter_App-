

class serviceListRequest {

  int? id;
  String? service_name;
  String? service_desc;
  String? createdAt;
  String? updatedAt;

  serviceListRequest({this.id, this.service_name, this. service_desc,
     this.createdAt, this. updatedAt}) ;

  factory serviceListRequest.fromJSON(Map<String,dynamic> json) {
    return serviceListRequest(
      id: json['id'] ?? 1,
      service_name: json['service_name'] ?? 'Food',
      service_desc: json['service_desc'] ?? 'Food Supply',
      createdAt: json['createdAt'] ?? '2024-05-16T11:58:14.000Z',
      updatedAt: json['updatedAt'] ?? '2024-05-16T11:58:14.000Z',
    );
  }


  Map<String, dynamic> toJson() {
    Map<String, dynamic> Service_List = {

      "id": id,
      "service_name": service_name,
      "service_desc ": service_desc,
      "createdAt": createdAt,
      "updateAt": updatedAt,
    };
    return Service_List;
  }

}
class serviceListResponse{

     bool? status;
     dynamic? data;
     String? message;
     //  serviceListResponse Object
  serviceListResponse({this.status,this.data,this.message});

  //factory constructor
  factory serviceListResponse.fromJSON(Map<String,dynamic> json){
    return serviceListResponse(
      status: json ['status'] != null ? json['status'] : true ,
      data: json['data'] != null ? json['data'] : '',
      message: json['message'] != null ? json['message'] : '',
    );

  }

}