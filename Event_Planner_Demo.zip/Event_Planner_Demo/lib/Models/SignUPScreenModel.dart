class SignUpRequest {
  String? Full_Name;
  String? Email;
  String? Phone_Number;
  String? Enter_Password;

  // Parameterized Constructor
  SignUpRequest(String? Full_Name, String? Email, String? Phone_Number, String? Enter_Password) {
    this.Full_Name = Full_Name ?? 'Default Name';
    this.Email = Email ?? 'default@example.com';
    this.Phone_Number = Phone_Number ?? '0000000000';
    this.Enter_Password = Enter_Password ?? 'default_password';
  }
  Map<String, dynamic> toJson() {
    Map<String, dynamic> mapping = {
      "name": Full_Name,
      "contact": Phone_Number,
      "email": Email,
      "password": Enter_Password,
    };
    return mapping;
  }
}
class SignUpResponse {
  // initlization JSON Keys
  String? message;
  bool? status;
  //  SignUpResponse is a object
  SignUpResponse({this.message, this.status});

  factory SignUpResponse.fromJSON(Map<String, dynamic> map) {
    return SignUpResponse(
      message: map["message"] != null ? map["message"] : "",
      status: map["status"] != null ? map["status"] : false,
    );
  }
}
