
class LoginRequest {
  String? email;
  String? password;

  LoginRequest({this.email, this.password});

  Map<String, dynamic> toJson() {
    Map<String, dynamic> mapping = {
      "email": email,
      "password": password,
    };
    return mapping;
  }
}

class LoginResponse {
  bool? status;
  String? token;
  final User? user;

  LoginResponse({this.status, this.token, this.user});

  factory LoginResponse.fromJson(Map<String, dynamic> json) {
    return LoginResponse(
      status: json['status'],
      token: json['token'],
      user:User.fromJson(json['user'])
    );
  }
}

class User {
  String? fullName;
  String? email;
  String? phoneNumber;
  String? enterPassword;

  User({this.fullName, this.email, this.phoneNumber, this.enterPassword});

  factory User.fromJson(Map<String, dynamic> map) {
    return User(
      fullName: map['Full_Name'] != null ? map['Full_Name'] : '',
      email: map['Email'] != null ? map['Email'] : '',
      phoneNumber: map['Phone_Number'] != null ? map['Phone_Number'] : '',
      enterPassword: map['Enter_Password'] != null ? map['Enter_Password'] : '',
    );
  }
}
