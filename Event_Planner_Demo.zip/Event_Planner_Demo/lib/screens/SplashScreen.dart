import 'dart:async';
import 'package:event_planner_demo/screens/HomeScreen.dart';
import 'package:event_planner_demo/screens/LoginScreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget
{
   @override
  State<SplashScreen> createState() => SplashScreenUI();
}
class SplashScreenUI extends State<SplashScreen>
{
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTime();
  }

  startTime() async {
    var duration = Duration(seconds: 3);
    return new Timer(duration, route);
  }

  route() {
    getDataFromSharedPreferences();

  }


  void getDataFromSharedPreferences () async
  {
    SharedPreferences sp = await SharedPreferences.getInstance();
   String? email = sp.getString("email");
   String? pass = sp.getString("pass");
   if(email != null && pass != null)
     {
       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomeScreen()));
     }
   else
     {
       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginScreen()));
     }
  }
  @override
  Widget build(BuildContext context) {
     return initWidget(context);
  }
  Widget initWidget(BuildContext context) {
    return Scaffold(
    backgroundColor: Color(0xff4391EC),
      body: Stack(
        children: [
          Center(
            child: Container(
              child: Image.asset('assets/Images/logo_prev_ui.png'),
            ),
          )
        ],
      ),
    );
  }
}