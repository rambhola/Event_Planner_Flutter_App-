import 'dart:convert';

import 'package:event_planner_demo/Models/EnquiryPageModel.dart';
import 'package:event_planner_demo/Models/LoginScreenModel.dart';
import 'package:event_planner_demo/Models/ServiceListModel.dart';
import 'package:event_planner_demo/Models/SignUpScreenModel.dart';
// import 'package:event_planner_demo/screens/ServiceListModel.dart';
import 'package:http/http.dart' as http;

class UserAPIService {
  Future<SignUpResponse> userRegister(SignUpRequest request) async {
    String api = "http://tutorials.codebetter.in:7087/auth/registercustomer";

    final response = await http.post(
      Uri.parse(api),
      body: request.toJson(),
    );

    print("Response Object is : ${response}");
    print("Response Body is : ${response.body}");

    var data = jsonDecode(response.body);

    if (data["status"]) {
      print("Success Response is : ${data}");
      return SignUpResponse.fromJSON(data);
    } else {
      print("Register Failed... ${data}");
      throw Exception("Failed...");
    }
  }

  Future<LoginResponse> userLogin(LoginRequest request) async {
    String api = "http://tutorials.codebetter.in:7087/auth/login";

    final response = await http.post(
      Uri.parse(api),
      body: request.toJson(),
    );

    print("Response Object is ${response}");
    print("Response body is ${response.body}");
    var data = jsonDecode(response.body);
    if (data["status"]) {
      print("Success Response is : ${data}");
      return LoginResponse.fromJson(data);
    } else {
      print("Response Failed... ${data}");
      throw Exception("Failed");
    }
  }

  Future<EnquiryResponse> userEnquiry(EnquiryRequest request) async {
    String api = "http://tutorials.codebetter.in:7087/auth/enquiry/save";
    final response = await http.post(Uri.parse(api),
      body: request.toJson(),
    );
    print("Response Object is ${response}");
    print("Response body is ${response.body}");
    var data = jsonDecode(response.body);
    if (data["status"]) {
      print("Success Response is : ${data}");
      return EnquiryResponse.fromJSON(data);
    } else {
      print("Response Failed... ${data}");
      throw Exception("Failed");
    }
  }


}