import 'package:event_planner_demo/Models/LoginScreenModel.dart';
import 'package:event_planner_demo/screens/HomeScreen.dart';
import 'package:event_planner_demo/screens/Serives/UserAPIService.dart';
import 'package:event_planner_demo/screens/SignUpScreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => LoginScreenUI();
}

// TextEditingController instances are used to retrieve the input from the text fields for email and password.
class LoginScreenUI extends State<LoginScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  // The build method constructs the UI by calling initWidget.
  @override
  Widget build(BuildContext context) {
    return initWidget();
  }

  // This method saves the email and password to SharedPreferences and navigates to the HomeScreen.
  void DataSavedInSharedPreferences(String token) async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    sp.setString('token', token);
    Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
  }

  // This method builds the UI for the login screen, including text fields, buttons, and decorations.
  Widget initWidget() {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Logo and Header:
            Container(
              height: 300,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(90)),
                color: Color(0xffF5591F),
                gradient: LinearGradient(
                  colors: [Color(0xff4391EC),Color(0xff4391EC)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 50),
                      child: Image.asset(
                        "assets/Images/app_logo.png",
                        height: 90,
                        width: 90,
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(right: 20, top: 20),
                      alignment: Alignment.bottomRight,
                      child: Text(
                        "Login",
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      ),
                    )
                  ],
                ),
              ),
            ),

            // Email Input Field:
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.only(left: 20, right: 20, top: 70),
              padding: EdgeInsets.only(left: 20, right: 20),
              height: 54,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.grey[200],
                boxShadow: [
                  BoxShadow(
                    offset: Offset(0, 10),
                    blurRadius: 50,
                    color: Color(0xffEEEEEE),
                  ),
                ],
              ),
              child: TextField(
                cursorColor: Color(0xffF5591F),
                controller: emailController,
                decoration: InputDecoration(
                  icon: Icon(
                    Icons.email,
                    color: Color(0xffF5591F),
                  ),
                  hintText: "Enter Email",
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                ),
              ),
            ),

            // Password Input Field
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.only(left: 20, right: 20, top: 20),
              padding: EdgeInsets.only(left: 20, right: 20),
              height: 54,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Color(0xffEEEEEE),
                boxShadow: [
                  BoxShadow(
                    offset: Offset(0, 20),
                    blurRadius: 100,
                    color: Color(0xffEEEEEE),
                  ),
                ],
              ),
              child: TextField(
                cursorColor: Color(0xffF5591F),
                controller: passwordController,
                decoration: InputDecoration(
                  focusColor: Color(0xffF5591F),
                  icon: Icon(
                    Icons.vpn_key,
                    color: Color(0xffF5591F),
                  ),
                  hintText: "Enter Password",
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                ),
              ),
            ),

            // Forget Password Text:
            Container(
              margin: EdgeInsets.symmetric(horizontal: 30, vertical: 20),
              alignment: Alignment.centerRight,
              child: GestureDetector(
                onTap: () {},
                child: Text("Forget Password?"),

              ),
            ),

            // Login Button:
            GestureDetector(
              onTap: () {

                Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));

                // Write Click Listener Code Here.
                String email = emailController.text;
                String pass = passwordController.text;
                LoginRequest loginRequest = LoginRequest(email: email, password: pass);
                UserAPIService service = UserAPIService();

                service.userLogin(loginRequest).then((value) {
                  print("value Object Is  : ${value}");
                  print("value Token Is  : ${value.token}");
                  print("value Token Is  : ${value.user?.fullName}");
                  String token = value.token!;
                  DataSavedInSharedPreferences(token);


                       // Write Tap Code Here.
                       Navigator.push(
                         context,
                         MaterialPageRoute(
                           builder: (context) => HomeScreen(),
                         ),
                       );
                });
              },
              child: Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(left: 20, right: 20, top: 70),
                padding: EdgeInsets.only(left: 20, right: 20),
                height: 54,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xff4391EC), Color(0xff4391EC)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(50),
                  color: Colors.grey[200],
                  boxShadow: [
                    BoxShadow(
                      offset: Offset(0, 10),
                      blurRadius: 50,
                      color: Color(0xffEEEEEE),
                    ),
                  ],
                ),
                child: Text(
                  "Login",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),

            // Register Now Text:
            Container(
              margin: EdgeInsets.only(top: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Don't Have Any Account?  "),
                  GestureDetector(
                    child: Text(
                      "Register Now",
                      style: TextStyle(color: Color(0xffF5591F)),
                    ),
                     onTap: () {

                     Navigator.push(
                         context,
                         MaterialPageRoute(
                           builder: (context) => SignUpScreen(),
                         ),
                       );
                     },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
