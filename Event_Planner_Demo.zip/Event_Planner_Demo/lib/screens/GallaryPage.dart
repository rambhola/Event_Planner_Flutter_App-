import 'package:flutter/material.dart';

class GallaryPage extends StatefulWidget {
  // const GallaryPage({super.key});
  @override
  State<GallaryPage> createState() => _GallaryPageState();
}

class _GallaryPageState extends State<GallaryPage> {
  List<String> GallaryImages = [
    ('assets/Images/GallaryImages/gallery01.jpg'),
    ('assets/Images/GallaryImages/gallery02.jpg'),
    ('assets/Images/GallaryImages/gallery03.jpg'),
    ('assets/Images/GallaryImages/gallery04.jpg'),
    ('assets/Images/GallaryImages/gallery06.jpg'),
    ('assets/Images/GallaryImages/gallery07.jpg'),
    ('assets/Images/GallaryImages/gallery08.jpg'),
    ('assets/Images/GallaryImages/gallery09.jpg'),
    ('assets/Images/GallaryImages/gallery10.jpg'),
    ('assets/Images/GallaryImages/gallery12.jpg'),
    ('assets/Images/GallaryImages/gallery13.jpg'),
    ('assets/Images/GallaryImages/gallery14.jpg'),
    ('assets/Images/GallaryImages/gallery15.jpg'),
    ('assets/Images/GallaryImages/gallery16.jpg'),
    ('assets/Images/GallaryImages/gallery17.jpg'),
    ('assets/Images/GallaryImages/gallery18.jpg')
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gallary', style: TextStyle(color: Colors.white)),
        centerTitle: true,
        backgroundColor: Color(0xff4391EC),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Container(
        padding: EdgeInsets.all(8),
        child: GridView.builder(
          itemCount: GallaryImages.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 4.0,
            mainAxisSpacing: 4.0,
          ),
          itemBuilder: (BuildContext context, int index) {
            return Image.asset(GallaryImages[index]);
          },
        ),
      ),
    );
  }
}
